/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File: main.cpp
 * Created on 05/14/2021 3:45 PM
 */

//iostream header that defines the standard input/output stream objects
#include <iostream>
#include "roster.h"
using namespace std;

//Student Data table modified to include personal information in the last line item
const string studentDataTable[] = {
    "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",//Refernce Requirement for project
    "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",//Refernce Requirement for project
    "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",//Refernce Requirement for project
    "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",//Refernce Requirement for project
    "A5,Stephan,Ward,sward1@wgu.edu,35,23,28,55,SOFTWARE"
};

int main() {

    //Creating Introduction to Program
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << "Created By: Stephan Francis Ward on 05/12/2021" << endl;
    cout << "Written in C++ Language" << endl;
    cout << "For Class C867-Scripting and Programming Applications" << endl;
    cout << "Student ID#: 001482765" << endl;
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    
    const int numStudent1 = 5;

    Roster classRoster;

    // Parse each student data and adds them to the classroster
    for (int i = 0; i < numStudent1; ++i) {
        classRoster.parseData(studentDataTable[i]);
    }

    //Prints the all information in class rooster
    classRoster.printAll();
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << std::endl;

    //Prints the Invalid Emails of the Rooster
    classRoster.printInvalidEmails();
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << std::endl;

    // Gets the average course days for each student in roster and prints
    for (int i = 0; i < numStudent1; ++i) {
        string studentID = classRoster.getStudentID(i);
        classRoster.printAveragedaysForCourse(studentID);
    }
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << std::endl;
    
    //Prints students with SOFTWARE degree
    classRoster.printByDegreeProgram(SOFTWARE);
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << std::endl;
    
    //Removes third row in the student rooster
    classRoster.remove("A3");

    //Prints all students in the class rooster
    classRoster.printAll();
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    cout << std::endl;

    //Removes third row in the student rooster
    classRoster.remove("A3");

    return 0;

}