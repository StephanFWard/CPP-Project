/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File roster.h
 * Created on 05/13/2021 3:45 PM
 */

#ifndef roster_h
#define roster_h
#include "student.h"

 // Creating class Roster
class Roster {
 //Public class Roster means the variables are available to everyone by the direct member access operator (.) with the object of Student class
public:
    Roster();

    /* This extracts the student data from the studentData Table by use of comma delimiters */
    void parseData(string studentData);

    /* This sets the Student object, containing parsed info, then adds the Student Object to the roster */
    void add(string studentID,
        string firstName,
        string lastName,
        string emailAddress1,
        int age,
        int daysForCourse1,
        int daysForCourse2,
        int daysForCourse3,
        DegreeProgram degreeProgram);

    /* Student removed from roster by his/her Student ID */
    void remove(string studentID);

    /* All student data from roster is printed as a list*/
    void printAll();

    /* The student's average day in three courses is printed */
    void printAveragedaysForCourse(string studentID);

    /* Checks student's email addresses and prints the invalid emails with description */
    void printInvalidEmails();

    /* Student info in a specified degree program is printed  */
    void printByDegreeProgram(DegreeProgram degreeProgram);

    string getStudentID(int num) const;

    ~Roster();

    Roster(const Roster& origRoster);

    Roster& operator=(const Roster& objToCopy);
// Private: can be accessed only by the functions inside the studentArray and classRosterArray class.
private:
    int studentArrayNum = -1;
    const static int numStudent1 = 5;
    Student* classRosterArray[numStudent1];

};

#endif /* roster_h */