/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File roster.cpp
 * Created on 05/13/2021 3:45 PM
 */

#include "roster.h"

using namespace std;

//Creating Roster class
Roster::Roster() {}

//Parsing student's data for Roster class
void Roster::parseData(string studentDataTable) {
    // Gets student's ID
    int commaIndex;
    commaIndex = studentDataTable.find(",");
    string studID = studentDataTable.substr(0, commaIndex);

    // Gets student's first name
    int startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string fName1 = studentDataTable.substr(startIndex, commaIndex - startIndex);

    // Gets student's last name
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string lName2 = studentDataTable.substr(startIndex, commaIndex - startIndex);

    // Gets student's email
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string email = studentDataTable.substr(startIndex, commaIndex - startIndex);

    // Gets student's age
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string years = (studentDataTable.substr(startIndex, commaIndex - startIndex));
    int age = stoi(years);

    // Gets Student's Days in Course 1
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string day1 = (studentDataTable.substr(startIndex, commaIndex - startIndex));
    int daysCourse1 = stoi(day1);

    // Gets Student's Days in Course 2
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string day2 = (studentDataTable.substr(startIndex, commaIndex - startIndex));
    int daysCourse2 = stoi(day2);

    // Gets Student's Days in Course 3
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string day3 = (studentDataTable.substr(startIndex, commaIndex - startIndex));
    int daysCourse3 = stoi(day3);

    // Get Student's Degree Program
    startIndex = commaIndex + 1;
    commaIndex = studentDataTable.find(",", startIndex);
    string degree = (studentDataTable.substr(startIndex, commaIndex - startIndex));

    // Finds Student's degree program
    int degreeNum = 0;
    for (long long unsigned int j = 0; j < sizeof(degreeProgramNames); ++j) {
        if ((degree.compare(degreeProgramNames[j])) == 0) {
            degreeNum = j;
            break;
        }
    }

    //Assignment of Degreeprogram
    DegreeProgram degreeProg = DegreeProgram(degreeNum);

    // Adds the students to the roster with the parsed data
    this->add(studID, fName1, lName2, email, age, daysCourse1, daysCourse2, daysCourse3, degreeProg);
}
//Creating Roster class object variable
void Roster::add(string studentID, string firstName,
    string lastName, string emailAddress1, int age,
    int daysForCourse1, int daysForCourse2, int daysForCourse3, DegreeProgram degreeProgram) {

    // Places days in course into the array that are needed for student rooster object
    int daysArray[3] = { daysForCourse1, daysForCourse2, daysForCourse3 };

    // Create new student object and then adds them to next spot in array
    ++studentArrayNum;
    classRosterArray[studentArrayNum] = new Student(studentID, firstName,
        lastName, emailAddress1, age, daysArray, degreeProgram);

}
//Creating Roster class object variable to find student ID
void Roster::remove(string studentID) {
    if (studentArrayNum > -1) {
        // Search method to see if student containing ID is in the roster
        int foundStudent = 0;

        for (int i = 0; i <= studentArrayNum; ++i) {
            string tempID = classRosterArray[i]->getID();

            // The student with associative student ID is checked to be found in the Class Rooster
            if (tempID.compare(studentID) == 0) {
                ++foundStudent;
                for (int j = i; j < studentArrayNum; ++j) {
                    classRosterArray[j] = classRosterArray[j + 1];
                }
                --studentArrayNum;
            }
        }

        // If student's ID is not found in the rooster, this error message will be displayed
        if (foundStudent == 0) {
            cout << "The Student containing the ID # " << studentID << " was not found in the roster." << endl;
        }
    }
    else {
        cout << "Students not found in the rooster." << endl;
    }

}

//Prints all the students
void Roster::printAll() {
    cout << "All students in current rooster displayed: " << endl;
    cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;

    // If no student in rooster is found, this error message is displayed
    if (studentArrayNum == -1) {
        cout << "Students are not found.";
        cout << "----------------------------------------------------------------------------------------------------------------------------------" << endl;
    }
    else {
        // This will print the data information for each student found in rooster.
        for (int i = 0; i <= studentArrayNum; ++i) {
            classRosterArray[i]->print();
        }
    }
}

//Creating method class to print the average days of a student in a course
void Roster::printAveragedaysForCourse(string studentID) {

    int foundStudent = 0; // Searches if student containing ID is found in the roster

    // Searches for a matching student with associative studentID in class roster
    for (int i = 0; i <= studentArrayNum; ++i) {
        string tempID = classRosterArray[i]->getID();

        // The student with associative student ID is checked to be found in the Class Rooster
        if (tempID.compare(studentID) == 0) {
            ++foundStudent;
            int totalDays = classRosterArray[i]->getDays()[0] + classRosterArray[i]->getDays()[1] + classRosterArray[i]->getDays()[2];
            double avg = totalDays / 3.0;
            cout << "Student ID# " << studentID << " has a average number of days in the three courses of: " << avg << endl;
        }
    }

    // If student is not found in the rooster, this error message is displayed
    if (foundStudent == 0) {
        cout << "The Student containing the ID # " << studentID << " was not found in the roster." << endl;
    }
}

//Creating class function to display all invalid emails from rooster array
void Roster::printInvalidEmails() {
    int trackInvalid = 0;
    cout << "All invalid emails are displayed: " << endl;

    /* Check if email is missing an at symbol (@) or period (.) or includes a space */
    for (int i = 0; i <= studentArrayNum; i++) {
        string tempEmail = classRosterArray[i]->getEmail();
        if (tempEmail.find('@') == string::npos || tempEmail.find('.') == string::npos || tempEmail.find(' ') != string::npos) {
            ++trackInvalid;

            if (tempEmail.find('@') == string::npos) {
                cout << tempEmail << " - This email is missing the @ symbol" << endl;
            }
            if (tempEmail.find('.') == string::npos) {
                cout << tempEmail << " - This email is missing a period" << endl;
            }
            if (tempEmail.find(' ') != string::npos) {
                cout << tempEmail << " - This email contains a space and is not allowed" << endl;
            }
        }
    }
    //If all emails are correct, this message is displayed
    if (trackInvalid == 0) {
        cout << "All emails are valid." << endl;
    }
}
//Creating class function to display specific degree programs from rooster array
void Roster::printByDegreeProgram(DegreeProgram degreeProgram) {
    cout << "Displaying students in specific degree program: ";
    cout << degreeProgramNames[degreeProgram] << endl;

    // Searches for a matching student with associative degree program in class roster
    for (int i = 0; i <= studentArrayNum; i++) {
        if (classRosterArray[i]->getDegree() == degreeProgram) {
            classRosterArray[i]->print();
        }
    }
}

string Roster::getStudentID(int num) const {
    return classRosterArray[num]->getID();
}
// Creating the roster destructor for objects that are removed
Roster::~Roster() {
    cout << "Object was removed, roster destructor called." << endl;

    for (int i = 0; i < numStudent1 - 1; ++i) {
        delete classRosterArray[i];
        classRosterArray[i] = nullptr;
    }
}
//Pointer to original rooster class assignment
Roster::Roster(const Roster& origRoster) {
    for (int i = 0; i < numStudent1; ++i) {
        classRosterArray[i] = new Student;
        *classRosterArray[i] = *(origRoster.classRosterArray[i]);
    }
}
//Gets Roster address
Roster& Roster::operator=(const Roster& objToCopy) {
    if (this != &objToCopy) {
        for (int i = 0; i < numStudent1; ++i) {
            delete classRosterArray[i];
            classRosterArray[i] = new Student;
            *classRosterArray[i] = *(objToCopy.classRosterArray[i]);
        }
    }
    return *this;
}