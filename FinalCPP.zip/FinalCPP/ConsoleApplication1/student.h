/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File: student.h
 * Created on 05/13/2021 3:45 PM
 */

 //iostream header that defines the standard input/output stream objects
#include <string>
#include <iostream>
#include "degree.h"

#ifndef student_h
#define student_h

using std::string;
using std::cout;

// Creating class Student
class Student {
//Public class Student means the variables are available to everyone by the direct member access operator (.) with the object of Student class
public:
    const static int studentArraySize = 3;
    // Constructors for class Student
    Student();
    Student(string studentID, string fName1, string lName2, string email, int age, int daysCourse[], DegreeProgram degree);

    // Destructor for class Student
    ~Student();

    Student(const Student& origStudent);

    // Assigning accessor (i.e., getter) for class student
    string getID() const;
    string getfName1() const;
    string getlName2() const;
    string getEmail() const;
    int getAge() const;
    int* getDays();
    DegreeProgram getDegree() const;

    // Assigning mutator (i.e., setter) for class student
    void setID(string studentID);
    void setfName1(string fName11);
    void setlName2(string lName2);
    void setEmail(string email);
    void setAge(int age);
    void setDaysCourse(int daysCourse[]);
    void setDegree(DegreeProgram deg);

    void print();

private:
//Private: can be accessed only by the functions inside the Student class.
    string studentID;
    string firstName;
    string lastName;
    string email;
    int age;
    int daysCourse[studentArraySize];
    DegreeProgram degree;
};
#endif /* STUDENT_H */
