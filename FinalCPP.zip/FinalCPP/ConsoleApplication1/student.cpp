/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File: student.cpp
 * Created on 05/13/2021 3:45 PM
 */

#include "student.h"
//Creation of the access operators
Student::Student() {
    this->studentID = "|";
    this->firstName = "|";
    this->lastName = "|";
    this->email = "|";
    this->age = 0;

    //Access operators referrences student array and associative days in course for index i
    for (int i = 0; i < studentArraySize; ++i) {
        this->daysCourse[i] = 0;
    }
}
//Creation of the access operators
Student::Student(string studentID, string fName1, string lName2, string email, int age, int daysCourse[], DegreeProgram degree) {
    this->studentID = studentID;
    this->firstName = fName1;
    this->lastName = lName2;
    this->email = email;
    this->age = age;

    //Access operators referrences student array and associative days in course for index j
    for (int j = 0; j < studentArraySize; ++j) {
        this->daysCourse[j] = daysCourse[j];
    }
    //Return is related to associated degree
    this->degree = degree;
}
//Student class assigned pointers linked to stings or integers and destuctor
Student::~Student() {}

string Student::getID() const { return this->studentID; }
string Student::getfName1() const { return this->firstName; }
string Student::getlName2() const { return this->lastName; }
string Student::getEmail() const { return this->email; }
int Student::getAge() const { return this->age; }
int* Student::getDays() { return this->daysCourse; }
DegreeProgram Student::getDegree() const { return this->degree; }
//Do not want to return a value
void Student::setID(string id) { this->studentID = id; }
void Student::setfName1(string fName1) { this->firstName = fName1; }
void Student::setlName2(string lName2) { this->lastName = lName2; }
void Student::setEmail(string email) { this->email = email; }
void Student::setAge(int age) { this->age = age; }
void Student::setDaysCourse(int daysCourse[]) {
    for (int k = 0; k < studentArraySize; ++k) {
        this->daysCourse[k] = daysCourse[k];
    }
}
void Student::setDegree(DegreeProgram deg) { this->degree = deg; }
//Void print student class function is used to not return a value
void Student::print() {
    cout << "Student ID#: " << this->getID() << '\t';
    cout << "Student's First Name: " << this->getfName1() << '\t';
    cout << "Student's Last Name: " << this->getlName2() << '\t';
    cout << "Student's Age: " << this->getAge() << '\t';
    //cout << "Student's Email: " << this->getEmail() << '\t';
    cout << "Student's Days in Course:(";
    for (int i = 0; i < studentArraySize; ++i) {
        if (i == (studentArraySize - 1)) {
            cout << this->getDays()[i] << ")" << '\t';
        }
        else {
            cout << this->getDays()[i] << ", ";
        }
    }
    cout << "Student Degree Program: " << degreeProgramNames[this->getDegree()] << std::endl;

}