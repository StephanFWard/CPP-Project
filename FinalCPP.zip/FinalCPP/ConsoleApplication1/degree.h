/*
 * Created By: Stephan Francis Ward
 * Class: C867 - Scirpting and Programming Applications
 * File: degree.h
 * Created on 05/13/2021 3:45 PM 
 */

#ifndef degree_h
#define degree_h

//Enumerated data type degree program created to contain specified values of: Security, Network, Software

enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };

static const std::string degreeProgramNames[] = { "SECURITY", "NETWORK", "SOFTWARE" };

#endif /* degree_h */